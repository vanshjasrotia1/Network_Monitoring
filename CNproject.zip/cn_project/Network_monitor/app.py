from flask import Flask, render_template, jsonify
import os
import platform
import speedtest
import socket
import time

app = Flask(__name__)

# Helper function to get network information
def get_network_info():
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)
    net_info = {
        "Hostname": hostname,
        "IP Address": ip_address,
        "Gateway": os.popen("ipconfig" if platform.system() == "Windows" else "route -n").read(),
        "Subnet Mask": os.popen("ipconfig" if platform.system() == "Windows" else "ifconfig").read(),
    }
    return net_info

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/measure-latency')
def measure_latency():
    host = "google.com"
    system = platform.system().lower()
    if 'windows' in system:
        command = f"ping -n 1 {host}"
    else:
        command = f"ping -c 1 {host}"
    result = os.popen(command).read()
    latency = result.split("time=")[-1].split("ms")[0] if "time=" in result else "N/A"
    return jsonify({"latency": latency})

@app.route('/measure-packet-loss')
def measure_packet_loss():
    try:
        system = platform.system().lower()
        if 'windows' in system:
            command = "ping -n 4 google.com"
        else:
            command = "ping -c 4 google.com"

        result = os.popen(command).read()
        lost_packets = int(result.split("Lost = ")[-1][0]) if "Lost" in result else 0
        total_packets = 4
        packet_loss = (lost_packets / total_packets) * 100
        return jsonify({"packet_loss": packet_loss})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/speed-test')
def speed_test():
    try:
        st = speedtest.Speedtest()
        download_speed = st.download() / 1_000_000  # Convert to Mbps
        upload_speed = st.upload() / 1_000_000      # Convert to Mbps
        return jsonify({
            "download_speed": round(download_speed, 2),
            "upload_speed": round(upload_speed, 2)
        })
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/network-info')
def network_info():
    try:
        info = get_network_info()
        return jsonify(info)
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/measure-rtt')
def measure_rtt():
    host = "google.com"
    start_time = time.time()
    system = platform.system().lower()
    if 'windows' in system:
        command = f"ping -n 1 {host}"
    else:
        command = f"ping -c 1 {host}"
    os.popen(command).read()
    rtt = (time.time() - start_time) * 1000  # Convert to milliseconds
    return jsonify({"rtt": round(rtt, 2)})

if __name__ == '__main__':
    app.run(debug=True)
